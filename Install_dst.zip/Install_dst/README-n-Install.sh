#!/bin/bash
# This README-Install.sh file:
# 
# 1. Prompts user to input target install directory. 
# 2. Defines LOGGER_HOME_PATH environment varible as the target directory and 
#    stores it in Logger_path.sh.
# 3. Creates the directory pointed to by LOGGER_HOME_PATH.
# 4. Prompts user to confirm target directory was successfuly created.
# 5. Create and copy file to subdirectories:
#           LOGGER_HOME_PATH/--+
#                              |
#                              +--/LogerOutput/
#                              |
#                              +--LoggerSecureVault/LoggerMessageDefines.txt
#                              |
#                              +--LoggerLibFree/LoggerLibFree.a
#                              |                /Logger_path.sh
#                              |
#                              +--user_application/Wandi-SASL-example.c
#                                          /README-n-Install.sh
#                                          /Makefile
#
# NOTE: The LOGGER_HOME_PATH environment variable in Logger_path.sh file is used
#       by the LoggerLibFree.a library APIs to read LoggerMessageDefines.txt file
#       and save log files to LoggerOutput subdirectory.
#
# Prompt the user for the target install directory.
read -r -p "Enter the installation directory full path: " LOGGER_HOME_PATH

# Create target install directory
if [ ! -d "$LOGGER_HOME_PATH" ]; then
    echo ">>>>> Directory does not exist. Creating: $LOGGER_HOME_PATH"
    mkdir -p "$LOGGER_HOME_PATH" || { echo ">>>>> Failed to create directory"; exit 1; }
fi

# Allow the user to confirm the target install directory is accurately created
read -r -p "Confirm directory was accurately created [y/n]: " CONFIRM
if [ "$CONFIRM" != "y" ]; then
	echo ">>>>> Aborting install"
	exit 1;
else
	echo ">>>>> Your confirmation is -> $CONFIRM"
fi

# Create all subdirectories
echo ">>>>> Installing files to $LOGGER_HOME_PATH..."
mkdir -p "$LOGGER_HOME_PATH/LoggerOutput"
mkdir -p "$LOGGER_HOME_PATH/LoggerSecureVault"
mkdir -p "$LOGGER_HOME_PATH/LoggerLibFree"
mkdir -p "$LOGGER_HOME_PATH/user_application"
#
# Copy appropriate files to subdirectories
cp LoggerLibFree.a $LOGGER_HOME_PATH/LoggerLibFree/.
cp LoggerMessageDefines.txt $LOGGER_HOME_PATH/LoggerSecureVault/.
cp Wandi-SASL-examples.c $LOGGER_HOME_PATH/user_application/.
cp Makefile $LOGGER_HOME_PATH/user_application/.
#
# make Wandi-SASL-example user application
cd $LOGGER_HOME_PATH/user_application
make all
#
cat << EOF >example_app.sh
export LOGGER_HOME_PATH=$LOGGER_HOME_PATH
echo "Using LOGGER_HOME_PATH: $LOGGER_HOME_PATH"
./Wandi-SASL-examples
EOF
cp example_app.sh $LOGGER_HOME_PATH/user_application/.
chmod 777 $LOGGER_HOME_PATH/user_application/example_app.sh
#
echo ">>>>> Installed directories and files:"
# List the target installed directories and files
ls -lrt $LOGGER_HOME_PATH/*
#
echo -e "\nGo to $LOGGER_HOME_PATH/user_application directory."
echo "Run ./example_app.sh to execute Wandi-SASL-examples.c program."
echo -e "Go to $LOGGER_HOME_PATH/LoggerOutput directory to view output files.\n"
#
echo ">>>>> Installation complete!"
